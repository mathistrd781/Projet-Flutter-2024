import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
    
  int _selectedIndex = 0;

  // Définis les pages correspondant à chaque élément de la barre de navigation
  final List<Widget> _pages = [
    MyHomePage(), // Page d'accueil
    NouvellePage(), // Page de recherche
    AfficherMoviesPage(), // Page des films
    AfficherSeriesPage(), // Page des séries
    AfficherComicsPage(), // Page des comics
  ];

  // Fonction pour changer de page lorsque l'utilisateur sélectionne un élément de la barre de navigation
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      print(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF15232E),
      appBar: AppBar(
        title: Text('ComicVine ECE'),
      ),
      body: _pages[_selectedIndex], // Utilisation de l'index pour afficher la page correspondante
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        unselectedItemColor: Colors.grey, // Couleur des éléments non sélectionnés
        selectedItemColor: Colors.orange, // Couleur de l'élément sélectionné
        currentIndex: _selectedIndex, // Index de l'élément sélectionné
        onTap: _onItemTapped, // Appelé lorsque l'utilisateur sélectionne un élément
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Accueil',),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Recherche',),
          BottomNavigationBarItem(icon: Icon(Icons.movie), label: 'Films',),
          BottomNavigationBarItem(icon: Icon(Icons.tv), label: 'Série',),
          BottomNavigationBarItem(icon: Icon(Icons.menu_book_outlined), label: 'Comics',),
        ],
      ),
    );
  }
}

class NouvellePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nouvelle Page'),
      ),
      body: Center(
        child: Text('Contenu de la nouvelle page'),
      ),
    );
  }
}

class AfficherMoviesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Mettez ici le code pour afficher les films
    return Container(); // Placeholder, à remplacer par le vrai contenu
  }
}

class AfficherSeriesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Mettez ici le code pour afficher les séries
    return Container(); // Placeholder, à remplacer par le vrai contenu
  }
}

class AfficherComicsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Mettez ici le code pour afficher les comics
    return Container(); // Placeholder, à remplacer par le vrai contenu
  }
}

Future<List<Movie>> fetchMovies() async {
  final response = await http.get(Uri.parse(
      'https://api.formation-android.fr/comicvine/?url=movies&api_key=755f59901d3302f979c5619481b0ed3564c6d3da&format=json&limit=10'));
  if (response.statusCode == 200) {
    final jsonData = json.decode(response.body);
    final List<Movie> movies = (jsonData['results'] as List)
        .map((movieJson) => Movie.fromJson(movieJson))
        .toList();
    return movies;
  } else {
    throw Exception('Failed to load movies');
  }
}

Future<List<Movie>> chargerDonneesDepuisFichier(BuildContext context) async {
  String contenuFichier = await DefaultAssetBundle.of(context).loadString('assets/listeFilm.json');
  final jsonData = json.decode(contenuFichier);

  // Récupère la liste de films à partir des données JSON
  final List<dynamic> results = jsonData['results'];

  // Map chaque élément de la liste en un objet Movie
  final List<Movie> movies = results.map((movieJson) {
    return Movie(
      name: movieJson['name'] ?? '',
      imageURL: movieJson['image']['medium_url'] ?? '',
    );
  }).toList();

  return movies;
}

class Movie {
  final String name;
  final String imageURL;

  Movie({required this.name, required this.imageURL});

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      name: json['name'] as String,
      imageURL: json['image']['medium_url'] as String,
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final Color textColor; // Nouveau paramètre pour la couleur de texte

  const SectionTitle({Key? key, required this.title, required this.textColor}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold, color: textColor), // Utilise la couleur de texte spécifiée
    );
  }
}
