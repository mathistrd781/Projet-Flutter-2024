import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    Acceuil(),

    Recherche(),



    MenuFilm(),
    MenuSerie(),
    MenuComic(),

  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF15232E),
      appBar: AppBar(
        title: Text('ComicVine ECE'),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        unselectedItemColor: Colors.grey,
        selectedItemColor: Colors.orange,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Accueil',),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Recherche',),
          BottomNavigationBarItem(icon: Icon(Icons.movie), label: 'Films',),
          BottomNavigationBarItem(icon: Icon(Icons.tv), label: 'Série',),
          BottomNavigationBarItem(icon: Icon(Icons.menu_book_outlined), label: 'Comics',),
        ],
      ),
    );
  }
}

class Acceuil extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: fetchMovies(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          // Si la requête échoue, charge les données à partir du fichier JSON local
          print("chargement depuis le fichier");
          return FutureBuilder(
            future: chargerDonneesDepuisFichier(context),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Erreur de chargement des données'));
              } else {
                final List<Movie> movies = snapshot.data as List<Movie>;
                return afficherMovies(movies);
              }
            },
          );
        } else {
          final List<Movie> movies = snapshot.data as List<Movie>;
          return afficherMovies(movies);
        }
      },
    );
  }
}

Widget afficherMovies(List<Movie> movies) {
  return SingleChildScrollView(
    scrollDirection: Axis.vertical,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Bienvenue !',
            style: TextStyle(fontSize: 24.0, color: Color(0xFFFFFFFF)),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.orange,
                ),
              ),
              SizedBox(width: 8.0),
              SectionTitle(title: 'Films', textColor: Color(0xFFFFFFFF)),
            ],
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: movies.map((movie) {
              return Container(
                margin: EdgeInsets.all(3.0),
                padding: EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Color(0xFF284C6A),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 150,
                      height: 200,
                      color: Color(0xFF284C6A),
                      child: movie.imageURL.isNotEmpty
                          ? CachedNetworkImage(
                        imageUrl: movie.imageURL,
                        placeholder: (context, url) =>
                            CircularProgressIndicator(),
                        errorWidget: (context, url, error) => Image.asset(
                          'assets/image/default2.jpg',
                          width: 150,
                          height: 200,
                        ),
                      )
                          : Image.asset(
                        'assets/image/default2.jpg',
                        width: 100,
                        height: 150,
                      ),
                    ),
                    SizedBox(height: 8.0),
                    Text(
                      movie.name,
                      style: TextStyle(fontSize: 16.0, color: Color(0xFFFFFFFF)),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
        SizedBox(height: 40.0),


        Container(
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.orange,
                ),
              ),
              SizedBox(width: 8.0),
              SectionTitle(title: 'Comics', textColor: Color(0xFFFFFFFF)),
            ],
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: movies.map((movie) {
              return Container(
                margin: EdgeInsets.all(3.0),
                padding: EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Color(0xFF284C6A),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 150,
                      height: 200,
                      color: Color(0xFF284C6A),
                      child: movie.imageURL.isNotEmpty
                          ? CachedNetworkImage(
                        imageUrl: movie.imageURL,
                        placeholder: (context, url) =>
                            CircularProgressIndicator(),
                        errorWidget: (context, url, error) => Image.asset(
                          'assets/image/default2.jpg',
                          width: 150,
                          height: 200,
                        ),
                      )
                          : Image.asset(
                        'assets/image/default2.jpg',
                        width: 100,
                        height: 150,
                      ),
                    ),
                    SizedBox(height: 8.0),
                    Text(
                      movie.name,
                      style: TextStyle(fontSize: 16.0, color: Color(0xFFFFFFFF)),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
        SizedBox(height: 40.0),


        Container(
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.orange,
                ),
              ),
              SizedBox(width: 8.0),
              SectionTitle(title: 'Séries', textColor: Color(0xFFFFFFFF)),
            ],
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: movies.map((movie) {
              return Container(
                margin: EdgeInsets.all(3.0),
                padding: EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Color(0xFF284C6A),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 150,
                      height: 200,
                      color: Color(0xFF284C6A),
                      child: movie.imageURL.isNotEmpty
                          ? CachedNetworkImage(
                        imageUrl: movie.imageURL,
                        placeholder: (context, url) =>
                            CircularProgressIndicator(),
                        errorWidget: (context, url, error) => Image.asset(
                          'assets/image/default2.jpg',
                          width: 150,
                          height: 200,
                        ),
                      )
                          : Image.asset(
                        'assets/image/default2.jpg',
                        width: 100,
                        height: 150,
                      ),
                    ),
                    SizedBox(height: 8.0),
                    Text(
                      movie.name,
                      style: TextStyle(fontSize: 16.0, color: Color(0xFFFFFFFF)),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
        SizedBox(height: 40.0),
      ],
    ),
  );
}

Future<List<Movie>> fetchMovies() async {
  final response = await http.get(Uri.parse(
      'https://api.formation-android.fr/comicvine/?url=movies&api_key=755f59901d3302f979c5619481b0ed3564c6d3da&format=json&limit=10'));
  if (response.statusCode == 200) {
    final jsonData = json.decode(response.body);
    final List<Movie> movies = (jsonData['results'] as List)
        .map((movieJson) => Movie.fromJson(movieJson))
        .toList();
    return movies;
  } else {
    throw Exception('Failed to load movies');
  }
}

Future<List<Movie>> chargerDonneesDepuisFichier(BuildContext context) async {
  String contenuFichier = await DefaultAssetBundle.of(context).loadString('assets/listeFilm.json');
  final jsonData = json.decode(contenuFichier);

  final List<dynamic> results = jsonData['results'];

  final List<Movie> movies = results.map((movieJson) {
    return Movie(
      name: movieJson['name'] ?? '',
      imageURL: movieJson['image']['medium_url'] ?? '',
    );
  }).toList();

  return movies;
}

class Movie {
  final String name;
  final String imageURL;

  Movie({required this.name, required this.imageURL});

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      name: json['name'] as String,
      imageURL: json['image']['medium_url'] as String,
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final Color textColor;

  const SectionTitle({
    Key? key,
    required this.title,
    required this.textColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: TextStyle(fontSize: 18.0, color: textColor),
    );
  }
}


class Recherche extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page de recherche'),
      ),
      body: Center(
        child: Text('Contenu de la nouvelle page'),
      ),
    );
  }
}

class MenuFilm extends StatefulWidget {
  @override
  _MenuFilmState createState() => _MenuFilmState();
}

class _MenuFilmState extends State<MenuFilm> {
  late Future<List<Movie2>> _futureMovies;

  @override
  void initState() {
    super.initState();
    _futureMovies = fetchMovies2();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _futureMovies,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Erreur de chargement des données'));
        } else {
          final List<Movie2> movies = snapshot.data as List<Movie2>;
          return ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: movies.length,
            itemBuilder: (context, index) {
              return buildMovieCard(movies[index]);
            },
          );
        }
      },
    );
  }

  Widget buildMovieCard(Movie2 movie) {
    return Container(
      margin: EdgeInsets.all(8.0),
      width: 200.0,
      padding: EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.0),
        color: Color(0xFF284C6A),

      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          ClipRRect(

            borderRadius: BorderRadius.vertical(top: Radius.circular(8.0)),
            child: CachedNetworkImage(
              imageUrl: movie.imageURL,
              placeholder: (context, url) => CircularProgressIndicator(),
              errorWidget: (context, url, error) => Container(
                width: 200,
                height: 200,
                color: Color(0xFF284C6A),
                child: Image.asset(
                  'assets/image/default2.jpg',
                  width: 200,
                  height: 200,
                  fit: BoxFit.cover,
                ),
              ),
              width: 200.0,
              height: 200.0,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  movie.name,
                  style: TextStyle(
                    fontSize: 30.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.white, // Couleur du texte en blanc
                  ),
                ),
                SizedBox(height: 30.0),
                Row(
                  children: [
                    Icon(
                      Icons.access_time,
                      color: Colors.white, // Couleur de l'icône en blanc
                    ),
                    SizedBox(width: 4.0),
                    Text(
                      '${movie.runtime} min',
                      style: TextStyle(
                        color: Colors.white, // Couleur du texte en blanc
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.0),
                Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      color: Colors.white, // Couleur de l'icône en blanc
                    ),
                    SizedBox(width: 4.0),
                    Text(
                      '${movie.releaseDate.year}',
                      style: TextStyle(
                        color: Colors.white, // Couleur du texte en blanc
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Movie2 {
  final String name;
  final String imageURL;
  final String runtime;
  final DateTime releaseDate;

  Movie2({
    required this.name,
    required this.imageURL,
    required this.runtime,
    required this.releaseDate,
  });

  factory Movie2.fromJson(Map<String, dynamic> json) {
    return Movie2(
      name: json['name'] as String,
      imageURL: json['image']['medium_url'] as String,
      runtime: json['runtime'] as String,
      releaseDate: DateTime.parse(json['release_date'] as String),
    );
  }
}

Future<List<Movie2>> fetchMovies2() async {
  final response = await http.get(Uri.parse(
      'https://api.formation-android.fr/comicvine/?url=movies&api_key=755f59901d3302f979c5619481b0ed3564c6d3da&format=json&limit=10'));
  if (response.statusCode == 200) {
    final jsonData = json.decode(response.body);

    final List<Movie2> movies = (jsonData['results'] as List)
        .map((movieJson) => Movie2.fromJson(movieJson))
        .toList();
    return movies;
  } else {
    throw Exception('Failed to load movies');
  }
}


class MenuSerie extends StatefulWidget {
  @override
  _MenuSerieState createState() => _MenuSerieState();
}

class _MenuSerieState extends State<MenuSerie> {
  late Future<List<Serie2>> _futureSerie;

  @override
  void initState() {
    super.initState();
    _futureSerie = fetchSerie2();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _futureSerie,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Erreur de chargement des données'));
        } else {
          final List<Serie2> movies = snapshot.data as List<Serie2>;
          return ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: movies.length,
            itemBuilder: (context, index) {
              return buildMovieCard(movies[index]);
            },
          );
        }
      },
    );
  }

  Widget buildMovieCard(Serie2 movie) {
    return Container(
      margin: EdgeInsets.all(8.0),
      width: 200.0,
      padding: EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.0),
        color: Color(0xFF284C6A),

      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          ClipRRect(

            borderRadius: BorderRadius.vertical(top: Radius.circular(8.0)),
            child: CachedNetworkImage(
              imageUrl: movie.imageURL,
              placeholder: (context, url) => CircularProgressIndicator(),
              errorWidget: (context, url, error) => Container(
                width: 200,
                height: 200,
                color: Color(0xFF284C6A),
                child: Image.asset(
                  'assets/image/default2.jpg',
                  width: 200,
                  height: 200,
                  fit: BoxFit.cover,
                ),
              ),
              width: 200.0,
              height: 200.0,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  movie.name,
                  style: TextStyle(
                    fontSize: 30.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.white, // Couleur du texte en blanc
                  ),
                ),
                SizedBox(height: 30.0),
                Row(
                  children: [
                    Icon(
                      Icons.access_time,
                      color: Colors.white, // Couleur de l'icône en blanc
                    ),
                    SizedBox(width: 4.0),
                    Text(
                      '${movie.runtime} min',
                      style: TextStyle(
                        color: Colors.white, // Couleur du texte en blanc
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.0),
                Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      color: Colors.white, // Couleur de l'icône en blanc
                    ),
                    SizedBox(width: 4.0),
                    Text(
                      '${movie.releaseDate.year}',
                      style: TextStyle(
                        color: Colors.white, // Couleur du texte en blanc
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Serie2 {
  final String name;
  final String imageURL;
  final String runtime;
  final DateTime releaseDate;

  Serie2({
    required this.name,
    required this.imageURL,
    required this.runtime,
    required this.releaseDate,
  });

  factory Serie2.fromJson(Map<String, dynamic> json) {
    return Serie2(
      name: json['name'] as String,
      imageURL: json['image']['medium_url'] as String,
      runtime: json['runtime'] as String,
      releaseDate: DateTime.parse(json['release_date'] as String),
    );
  }
}

Future<List<Serie2>> fetchSerie2() async {
  final response = await http.get(Uri.parse(
      'https://api.formation-android.fr/comicvine/?url=series&api_key=755f59901d3302f979c5619481b0ed3564c6d3da&format=json&limit=10'));
  if (response.statusCode == 200) {
    final jsonData = json.decode(response.body);

    final List<Serie2> movies = (jsonData['results'] as List)
        .map((movieJson) => Serie2.fromJson(movieJson))
        .toList();
    return movies;
  } else {
    throw Exception('Failed to load serie');
  }
}


class MenuComic extends StatefulWidget {
  @override
  _MenuComicState createState() => _MenuComicState();
}

class _MenuComicState extends State<MenuComic> {
  late Future<List<Comic2>> _futureComic;

  @override
  void initState() {
    super.initState();
    _futureComic = fetchComic2();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _futureComic,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Erreur de chargement des données'));
        } else {
          final List<Comic2> movies = snapshot.data as List<Comic2>;
          return ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: movies.length,
            itemBuilder: (context, index) {
              return buildMovieCard(movies[index]);
            },
          );
        }
      },
    );
  }

  Widget buildMovieCard(Comic2 movie) {
    return Container(
      margin: EdgeInsets.all(8.0),
      width: 200.0,
      padding: EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.0),
        color: Color(0xFF284C6A),

      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          ClipRRect(

            borderRadius: BorderRadius.vertical(top: Radius.circular(8.0)),
            child: CachedNetworkImage(
              imageUrl: movie.imageURL,
              placeholder: (context, url) => CircularProgressIndicator(),
              errorWidget: (context, url, error) => Container(
                width: 200,
                height: 200,
                color: Color(0xFF284C6A),
                child: Image.asset(
                  'assets/image/default2.jpg',
                  width: 200,
                  height: 200,
                  fit: BoxFit.cover,
                ),
              ),
              width: 200.0,
              height: 200.0,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  movie.name,
                  style: TextStyle(
                    fontSize: 30.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.white, // Couleur du texte en blanc
                  ),
                ),
                SizedBox(height: 30.0),
                Row(
                  children: [
                    Icon(
                      Icons.access_time,
                      color: Colors.white, // Couleur de l'icône en blanc
                    ),
                    SizedBox(width: 4.0),
                    Text(
                      '${movie.runtime} min',
                      style: TextStyle(
                        color: Colors.white, // Couleur du texte en blanc
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.0),
                Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      color: Colors.white, // Couleur de l'icône en blanc
                    ),
                    SizedBox(width: 4.0),
                    Text(
                      '${movie.releaseDate.year}',
                      style: TextStyle(
                        color: Colors.white, // Couleur du texte en blanc
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Comic2 {
  final String name;
  final String imageURL;
  final String runtime;
  final DateTime releaseDate;

  Comic2({
    required this.name,
    required this.imageURL,
    required this.runtime,
    required this.releaseDate,
  });

  factory Comic2.fromJson(Map<String, dynamic> json) {
    return Comic2(
      name: json['name'] as String,
      imageURL: json['image']['medium_url'] as String,
      runtime: json['runtime'] as String,
      releaseDate: DateTime.parse(json['release_date'] as String),
    );
  }
}

Future<List<Comic2>> fetchComic2() async {
  final response = await http.get(Uri.parse(
      'https://api.formation-android.fr/comicvine/?url=series&api_key=755f59901d3302f979c5619481b0ed3564c6d3da&format=json&limit=10'));
  if (response.statusCode == 200) {
    final jsonData = json.decode(response.body);

    final List<Comic2> movies = (jsonData['results'] as List)
        .map((movieJson) => Comic2.fromJson(movieJson))
        .toList();
    return movies;
  } else {
    throw Exception('Failed to load Comic');
  }
}

