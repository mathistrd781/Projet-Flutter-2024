package com.example.projetfilm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
